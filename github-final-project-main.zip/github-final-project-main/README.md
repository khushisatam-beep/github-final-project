# github-final-project
Final project for IBM Github UI
# This is the README.md file for the **github-final-project**

A calculator that calculates simple interest given principal, annual rate of interest and time period in years.

Input:

   p, principal amount  
   t, time period in years  
   r, annual rate of interest  

Output:
   simple interest = (p * t * r) / 100
